# &#x20;                                            DSA Assignment



**Name:** Sachin

**Student ID:** BC2025114



 

## How to Run

```
gcc stack.c -o stack
./stack

gcc circular\_queue.c -o cq
./cq
```

 

\---

 

## Q1. Stack using Array

A stack follows **LIFO** (Last In, First Out). Insertion and deletion happen only at the **top**.
`top = -1` means the stack is empty.

 

### Complexity

|Operation|Time|Extra Space|
|-|-|-|
|PUSH|O(1)|O(1)|
|POP|O(1)|O(1)|
|PEEK|O(1)|O(1)|
|DISPLAY|O(n)|O(1)|

PUSH, POP and PEEK work on a single position, so they take constant time. DISPLAY visits all n elements. The array itself takes O(n) space.

 

### Overflow and Underflow

* **Stack Underflow:** POP or PEEK on an empty stack (`top == -1`).
* **Stack Overflow:** PUSH on a full stack (`top == MAX - 1`).

 

### What if a fixed-size stack is full?

The array has fixed slots. Pushing one more element would write outside the array, which can corrupt memory or crash the program. So PUSH checks for a full stack first, prints "Stack Overflow", and does not insert.

 

\---

 

## Q2. Circular Queue using Array

A queue follows **FIFO** (First In, First Out). Insert at the **rear**, delete from the **front**.
In a circular queue, the last index connects back to index 0 using `(index + 1) % MAX`.

 

### Full vs Empty

A variable `count` stores the number of elements.

* `count == 0` → queue is **empty**
* `count == MAX` → queue is **full**

Without `count`, `front` and `rear` look the same in both cases.

 

### Complexity

|Operation|Time|Extra Space|
|-|-|-|
|ENQUEUE|O(1)|O(1)|
|DEQUEUE|O(1)|O(1)|
|FRONT|O(1)|O(1)|
|DISPLAY|O(n)|O(1)|

 

### Circular Queue vs Linear Queue

**1. Memory use:** In a linear queue, slots freed at the start are never reused. A circular queue wraps around and reuses them.

**2. Time complexity:** ENQUEUE and DEQUEUE are both O(1).

**3. Space complexity:** O(n) for an array of size n.

**4. Linear queue problem:** When `rear` reaches the last index, the queue shows "full" even if positions at the beginning are empty. This is called false overflow. A circular queue avoids it.

 

### Example (MAX = 5)

1. Enqueue 1, 2, 3, 4, 5. The queue is full.
2. Dequeue twice. Positions 0 and 1 are free.
3. Enqueue 7 and 8. They go into positions 0 and 1. A linear queue would reject them.

