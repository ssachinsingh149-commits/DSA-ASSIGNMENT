#include <stdio.h>

#define MAX 5

int queue[MAX];
int front = 0;
int rear = 0;
int count = 0;

void enqueue(int x) {
    if (count == MAX) {
        printf("Queue Overflow! Cannot insert %d\n", x);
    } else {
        queue[rear] = x;
        rear = (rear + 1) % MAX;
        count = count + 1;
        printf("%d inserted\n", x);
    }
}

void dequeue() {
    if (count == 0) {
        printf("Queue Underflow! Queue is empty\n");
    } else {
        printf("%d deleted\n", queue[front]);
        front = (front + 1) % MAX;
        count = count - 1;
    }
}

void showFront() {
    if (count == 0) {
        printf("Queue is empty\n");
    } else {
        printf("Front element = %d\n", queue[front]);
    }
}

void display() {
    if (count == 0) {
        printf("Queue is empty\n");
    } else {
        printf("Queue elements: ");
        for (int i = 0; i < count; i++) {
            printf("%d ", queue[(front + i) % MAX]);
        }
        printf("\n");
    }
}

int main() {
    int choice, value;

    while (1) {
        printf("\n1. ENQUEUE\n2. DEQUEUE\n3. FRONT\n4. DISPLAY\n5. EXIT\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        if (choice == 1) {
            printf("Enter value: ");
            scanf("%d", &value);
            enqueue(value);
        } else if (choice == 2) {
            dequeue();
        } else if (choice == 3) {
            showFront();
        } else if (choice == 4) {
            display();
        } else if (choice == 5) {
            break;
        } else {
            printf("Invalid choice\n");
        }
    }
    return 0;
}
